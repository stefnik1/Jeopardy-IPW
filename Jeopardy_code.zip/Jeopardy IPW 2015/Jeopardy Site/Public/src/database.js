



var jeopardy = (function() {
	return {
		options: ['100', '200', '300', '400', '500'],
		questions_100: ['1?', '2?', '3?', '4?', '5?'],
		counter_clockwise: ['9','8','7','6','5','4','3','2','1'],
		 numere: ['1', '2', '3', '4', '5'],
		 seconds: 30,
		 value: 9000,
		 color: '',
		 name: '',
		 scor: 0,
		 //counter: 0,
		categories: {
			'TARGU-MURES': {
				'100':
				{
					available: true,
					intrebare: 'Ce rau trece prin Targu-Mures?',
					raspuns: 'Mures',
					scor: 100
				},
				'200':
				{
					available: true,
					intrebare: 'Unde se afla Subway in Targu-Mures?',
					raspuns: 'Nu exista',
					scor: 200
				},
				'300':
				{
					available: true,
					intrebare: 'Cum se numeste cinematograful din centru?',
					raspuns: 'Arta',
					scor: 300
				},
				'400':
				{
					available: true,
					intrebare: 'Cum il chema pe primul primar roman al orasului?',
					raspuns: 'Emil Dandea',
					scor: 400
				},
				'500':
				{
					available: true,
					intrebare: 'Care este cea mai importanta facultate din Targu-Mures?',
					raspuns: 'UMF',
					scor: 500
				}
			},
			'MASINI': {
				'100':
				{
					available: true,
					intrebare: 'Logo-ul Maserati este...?',
					raspuns: 'un trident',
					scor: 100
				},
				'200':
				{
					available: true,
					intrebare: 'Cum se numeste personajul principal din animatia Cars?',
					raspuns: 'Fulger McQueen',
					scor: 200
				},
				'300':
				{
					available: true,
					intrebare: 'Ce companie producatoare de masini a fost cunoscuta initial sub numele de Swallow Sidecars?',
					raspuns: 'Jaguar',
					scor: 300
				},
				'400':
				{
					available: true,
					intrebare: 'In tinerete, Henry Ford obisnuia sa repare...',
					raspuns: 'Ceasuri',
					scor: 400
				},
				'500':
				{
					available: true,
					intrebare: 'Primul automobil cu radio a fost vandut in anul...',
					raspuns: '1923',
					scor: 500
				}
			},
			'SPORT': {
				'100':
				{
					available: true,
					intrebare: 'Unde este aprinsa flacara olimpica?',
					raspuns: 'In Olimpia, Grecia',
					scor: 100
				},
				'200':
				{
					available: true,
					intrebare: 'Din ce tara provine jucatorul de tenis Novak Djokovic?',
					raspuns: 'Serbia',
					scor: 200
				},
				'300':
				{
					available: true,
					intrebare: 'Cine a castigat Turul Frantei din 2013?',
					raspuns: 'Chris Froome',
					scor: 300
				},
				'400':
				{
					available: true,
					intrebare: 'In ce an a castigat Nadia Comaneci medalia de aur?',
					raspuns: '1976',
					scor: 400
				},
				'500':
				{
					available: true,
					intrebare: 'In ce an s-a nascut Roger Federer?',
					raspuns: '1981',
					scor: 500
				}
			},
			'IP WORKSHOP': {
				'100':
				{
					available: true,
					intrebare: 'Ce striga Brebu pe munte?',
					raspuns: 'Haide, haide!',
					scor: 100
				},
				'200':
				{
					available: true,
					intrebare: 'Unde a fost gasita cheia de la camera 219D?',
					raspuns: 'In buzunarul lui Alexandru Radovici',
					scor: 200
				},
				'300':
				{
					available: true,
					intrebare: 'Cine baleste pe ceas cand doarme?',
					raspuns: 'Razvan Barbascu',
					scor: 300
				},
				'400':
				{
					available: true,
					intrebare: 'Ce culoare sustine Pelin ca are echipa sa?',
					raspuns: 'Siclam',
					scor: 400
				},
				'500':
				{
					available: true,
					intrebare: 'Cate colturi are un patrat?',
					raspuns: 'Sasah',
					scor: 500
				}
			},
			'MUZICA': {
				'100':
				{
					available: true,
					intrebare: 'Cine canta melodia Thunderstruck?',
					raspuns: 'AC/DC',
					scor: 100
				},
				'200':
				{
					available: true,
					intrebare: 'Cine nu ma cum ma tu?',
					raspuns: 'Delia',
					scor: 200
				},
				'300':
				{
					available: true,
					intrebare: 'De la cate grade m-ai adus la zero, zero grade?',
					raspuns: '30 de grade',
					scor: 300
				},
				'400':
				{
					available: true,
					intrebare: 'Daca dragostea dispare...?',
					raspuns: 'Viata mea n-are culoare',
					scor: 400
				},
				'500':
				{
					available: true,
					intrebare: 'Vreau sa-mi fac ... in fata portii.',
					raspuns: 'Statuie',
					scor: 500
				}
			}
		},
		players: [ 
		]
	};
})();