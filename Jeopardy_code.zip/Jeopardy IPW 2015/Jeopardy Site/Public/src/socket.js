var socket = io.connect('http://ioana-mculic-jeopardy.iot.wyliodrin.com');

socket.on('answer', function(object) {

	console.log(object);
	jeopardy.color = object.color.color;
	jeopardy.name = object.color.name;
	
});
