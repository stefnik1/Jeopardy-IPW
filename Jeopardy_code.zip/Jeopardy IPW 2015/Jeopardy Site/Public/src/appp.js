(function() {

	var app = angular.module('jeo', []);

	app.directive('bodyGrid', function() {
		return {
			restrict: 'E',
			templateUrl: 'html/body-grid.html',
			controller: function() {
				this.options = jeopardy.options;

			},
			controllerAs: 'gridCtrl'
		};
	});
	app.directive('clock', function() {
		return {
			restrict: 'E',
			templateUrl: 'html/clock.html',
			controller: function() {

				this.numbers = jeopardy.counter_clockwise;
				},
			
			controllerAs: 'clockCtrl'
		};
	});
	app.directive('initBody', function() {
		return {
			restrict: 'E',
			templateUrl: 'html/init-body.html',
			controller: function() {

				this.click = 1;

				this.setClick = function(click) {
					this.click = click;
				};

				this.isClicked = function() {
					return this.click;
				};
			},
			controllerAs: 'bodyCtrl'
		};
	});
	
	app.directive('tabelCategorii', ['$http', function($http) {
		return {
			restrict: 'E',
			scope: {
				clasa: "@",
				intrebare: "=",
				seconds: "@",
				raspuns: "="
				},
			templateUrl: 'html/tabel-categorii.html',
			controller: function($scope) {

				$scope.intrebare = "";
				this.categories = jeopardy.categories;
				this.options = jeopardy.options;
				$scope.players = jeopardy.players;
				//var counter = 0;
				this.showModal = function(nume, index) {
					//counter += 1;
					$('.intrebare').modal('show');
					$scope.intrebare = jeopardy.categories[nume][index].intrebare;
					$scope.raspuns = jeopardy.categories[nume][index].raspuns;
					jeopardy.scor = jeopardy.categories[nume][index].scor;
					jeopardy.categories[nume][index].available = false;
					
					// jeopardy.counter = counter;
					console.log(jeopardy.scor);

					$http.get('http://ioana-mculic-jeopardy.iot.wyliodrin.com/new').then(function(response) {
					}, function(response) {
					alert('error');
				});
				
					
				};
				
				$http.get('http://ioana-mculic-jeopardy.iot.wyliodrin.com/get_users').then(function(response) {
						var createNewPlayer = function(nume, color) {
							var newPlayer = {};
							newPlayer.nume = nume;
							newPlayer.color = color;
							newPlayer.scor = 0; 
							//console.log (newPlayer);
							jeopardy.players.push(newPlayer);
						}
						for(player in response.data) {
							createNewPlayer(response.data[player].name, response.data[player].color);
						}
						createNewPlayer('marius', 'red');
						console.log(jeopardy.players);
						//console.log(response.data);
						
					}, function(response) {
					alert('error');
				});

				

				

				var socket = io.connect('http://ioana-mculic-jeopardy.iot.wyliodrin.com');
				
				$scope.scor = jeopardy.scor;
				socket.on('answer', function(object) {

					$scope.color = object.color.color;
					$scope.name = object.color.name;
					object.color.score = 0;

					$('.show_name').show();
					functie();
					$scope.$apply();

				});
				
				console.log(jeopardy.players);
				//function: clock stops when a button is pressed; j.value: 5000;
				
				var stopClock = function() {
					window.setTimeout(function(){
    					 $('.intrebare').modal('hide');
  					}, jeopardy.value);

				};
				var functie = function() {
					
				if($scope.color !== '' && $scope.name !== '') {
							
							$scope.clock.stop();
							stopClock();
					}

				};
				console.log($scope.scor);
				$scope.correct = function(setVar) {

					//add points

					if(setVar === 1) {
						for(player in jeopardy.players) {
							if(player.color === $scope.color) {
								player.score += jeopardy.scor;
								
							}
						}
						
					}
										
				};

				$scope.$watch ('intrebare', function ()
				{
					$('.message').hide();
					$('.show_name').hide();
					$scope.clock = new FlipClock($('.clock'), jeopardy.seconds, {
						clockFace: 'Counter',
						autoStart: true,
						countdown: true,
						callbacks: {
							// if fails to answer in 10 seconds; doesn't add score;
							stop: function() {
								window.setTimeout(function() {
									$('.message').show();
								}, 2000);
								

								stopClock();

							}
						}

					});

				});
				 
			},
			controllerAs: 'tabelCtrl'
		};
	}]);
	
	
	
	app.directive('scoreContainer', function() {
		return {
			restrict: 'E',
			templateUrl: 'html/score-container.html',
			controller: function($scope) {
				$scope.players = jeopardy.players;
				console.log(jeopardy.players);
			},
			controllerAs: 'scoreCtrl'
		};
	});
	// app.directive('winner', function() {
	// 	return {
	// 		restrict: 'E',
	// 		templateUrl: 'html/winner.html',
	// 		controller: function($scope) {
				
	// 		},
	// 		controllerAs: 'winnerCtrl'
	// 	};
	// });

	
	
})();