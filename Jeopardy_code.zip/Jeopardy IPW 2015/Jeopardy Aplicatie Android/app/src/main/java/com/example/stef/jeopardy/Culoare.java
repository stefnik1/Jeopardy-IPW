package com.example.stef.jeopardy;

/**
 * Created by Stef on 13.08.2015.
 */
public class Culoare {
        public String nume;
        public String id;
        public Culoare(String c){
            this.nume=c;
        }
        public String toString()
        {
            return nume;
        }
    }
