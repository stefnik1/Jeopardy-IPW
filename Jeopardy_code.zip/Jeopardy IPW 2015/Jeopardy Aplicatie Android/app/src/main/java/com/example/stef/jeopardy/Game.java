package com.example.stef.jeopardy;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

/**
 * Created by Stef on 13.08.2015.
 */
public class Game extends Activity {
    TextView ed;
    String color;
    ImageView icon;
    Button newBut;
    Button anotherBut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_game);
        ed = (TextView) findViewById(R.id.txt1);
        final String name = getIntent().getStringExtra("name");
        ed.setText(name);
        color = getIntent().getStringExtra("color");
        System.out.println(color);
        icon = (ImageView) findViewById(R.id.but1);
        newBut = (Button) findViewById(R.id.buton1);
        anotherBut = (Button) findViewById(R.id.buton2);
        if (color.equals("red"))
            icon.setBackgroundColor(Color.parseColor("#FF0000"));
        else if (color.equals("yellow"))
            icon.setBackgroundColor(Color.parseColor("#ffd700"));
        else if (color.equals("green"))
            icon.setBackgroundColor(Color.parseColor("#008b00"));
        else if (color.equals("blue"))
            icon.setBackgroundColor(Color.parseColor("#483D8B"));
        newBut.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        JSONObject jo = new JSONObject();
                        try {
                            jo.put("color",color);
                            new LongOperation(Game.this).execute("answer", jo.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
        anotherBut.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        finish();
                    }
                });
    }
        class LongOperation extends AsyncTask<String, Void, JSONObject> {
            public String myId;
            Context activity;

            public LongOperation(Context ctx) {
                activity = ctx;
            }

            @Override
            protected JSONObject doInBackground(String... params) {
                String action = params[0];
                try {
                    JSONObject newJ = new JSONObject(params[1]);
                    if (action.equals("answer")) {
                        String path = "http://ioana-mculic-jeopardy.iot.wyliodrin.com/answer";
                        HttpClient httpclient = new DefaultHttpClient();
                        HttpPost httpost = new HttpPost(path);
                        StringEntity se = null;
                        se = new StringEntity(params[1]);
                        httpost.setEntity(se);
                        httpost.setHeader("Accept", "application/json");
                        httpost.setHeader("Content-type", "application/json");
                        ResponseHandler responseHandler = new BasicResponseHandler();
                        HttpResponse responsePost = httpclient.execute(httpost);
                        HttpEntity rasp_entity = responsePost.getEntity();
                        String res = EntityUtils.toString(rasp_entity);
                        if (res != null) {
                            JSONObject anotherJson = new JSONObject(res);
                            if (anotherJson.getString("result").toString().equals("done"))
                                return newJ;
                            else
                                return null;
                        }
                    }
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return null;
            }

            public void onPostExecute(JSONObject result) {
                if (result == null) {
                    Toast.makeText(Game.this, "!", Toast.LENGTH_LONG).show();
                } else {
                    Intent intent = new Intent(activity, Game.class);
                    try {
                        intent.putExtra("response", result.getString("color"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }
        }
    }
