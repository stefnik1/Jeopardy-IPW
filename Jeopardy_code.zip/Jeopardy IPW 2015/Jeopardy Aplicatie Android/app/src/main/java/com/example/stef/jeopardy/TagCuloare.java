package com.example.stef.jeopardy;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Stef on 13.08.2015.
 */
public class TagCuloare {
    public TextView nume;
    public ImageView img;
}
