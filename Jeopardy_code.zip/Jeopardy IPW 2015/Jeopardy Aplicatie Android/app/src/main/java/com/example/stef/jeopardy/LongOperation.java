package com.example.stef.jeopardy;

/**
 * Created by Stef on 14.08.2015.
 */

import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * Created by Stef on 14.08.2015.
 */
public class LongOperation extends AsyncTask<String, Void, Integer> {
public String myId;
    @Override
    protected Integer doInBackground(String... params) {
        String action =params[0];
        if(action.equals("register")){
            String path="http://ioana-mculic-jeopardy.iot.wyliodrin.com/register";
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httpost = new HttpPost(path);
            StringEntity se = null;
            try {
                se = new StringEntity(params[1]);
                httpost.setEntity(se);
               // httpost.setHeader("host", "http://ioana-mculic-jeopardy.iot.wyliodrin.com");
                httpost.setHeader("Accept", "application/json");
                httpost.setHeader("Content-type", "application/json");
                ResponseHandler responseHandler = new BasicResponseHandler();
                HttpResponse responsePost = httpclient.execute(httpost);
                HttpEntity rasp_entity= responsePost.getEntity();
                if (rasp_entity!= null) {
                    Log.i("RESPONSE", EntityUtils.toString(rasp_entity));
                    JSONObject myJson = new JSONObject(EntityUtils.toString(rasp_entity));
                    if(myJson.getString("result").toString().equals("done"))
                    {
                        return 1;
                    }
                    else
                        return 0;
                }

                }
            catch (JSONException e) {
                e.printStackTrace();
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return 1;
    }
}


