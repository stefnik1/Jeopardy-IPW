package com.example.stef.jeopardy;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Stef on 13.08.2015.
 */
public class ActivAdapter extends BaseAdapter {
        private Activity context;
        ArrayList<Culoare> colors;
        public Integer[] imgid;
        public ActivAdapter(Activity _context){
            this.context= _context;
            colors = new ArrayList<Culoare>();
            colors.add(new Culoare("red"));
            colors.add(new Culoare("yellow"));
            colors.add(new Culoare("green"));
            colors.add(new Culoare("blue"));
            this.imgid=imgid;
        }

        public View getView (int position, View convertView, ViewGroup list)
        {
            // functia trebuie sa intoarca view-ul de pe pozitia position din lista
            // convertView este un element din lista ce nu mai este vizibil si poate fi convertit
            View element;

            if(convertView == null) {
                    LayoutInflater inflater = context.getLayoutInflater();
                    element = (View) inflater.inflate(R.layout.choice, null);
                    TagCuloare tag = new TagCuloare();
                    tag.nume = (TextView) element.findViewById(R.id.culoare);
                    tag.img = (ImageView) element.findViewById(R.id.icon);
                    element.setTag(tag);
                }
            else
                element=convertView;
            TagCuloare tag = (TagCuloare) element.getTag();

            tag.nume.setText(colors.get(position).nume);
            if (tag.nume.getText().toString().equals("red"))
                tag.img.setBackgroundColor(Color.parseColor("#FF0000"));
            else if (tag.nume.getText().toString().equals("yellow"))
                tag.img.setBackgroundColor(Color.parseColor("#ffd700"));
            else if (tag.nume.getText().toString().equals("green"))
                tag.img.setBackgroundColor(Color.parseColor("#008b00"));
            else if (tag.nume.getText().toString().equals("blue"))
                tag.img.setBackgroundColor(Color.parseColor("#483D8B"));
            return element;
        }

        public int getCount ()
        {
            // intoarce nr de elemente din lista
            return colors.size ();
        }

        public Object getItem(int position)
        {
            // intoarce elementul de pe pozitia position din model
            if(getItemViewType(position)==0)
                return colors.get(getViewTypeCount());
            else
                return colors.get(1);
        }

        public long getItemId(int position)
        {
        // fiecare element din lista poate avea un id, nu este insa obligatoriu
        return 0;
    }

    public void adaugaCuloare(String nume)
    {
        Culoare p = new Culoare (nume);
        p.nume = nume;
        colors.add (p);
        this.notifyDataSetChanged();
    }
}
