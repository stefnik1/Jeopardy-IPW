package com.example.stef.jeopardy;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutionException;

/**
 * Created by Stef on 13.08.2015.
 */
public class NewActivity extends ListActivity {
    TextView t;
    ActivAdapter adapter;
    Button mButton;
    EditText t1;
    Culoare cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity);
        t = (TextView) findViewById(R.id.txt1);
        String txt = getIntent().getStringExtra("buton");
        t.setText("New " + txt + "er");
        adapter = new ActivAdapter(this);
        setListAdapter(adapter);
        cl = adapter.colors.get(0);
        mButton = (Button) findViewById(R.id.b1);
        t1 = (EditText) findViewById(R.id.e1);

        mButton.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {


                        JSONObject jo = new JSONObject();

                        try {
                            jo.put("name", t1.getText().toString());
                            jo.put("color", cl.nume);
                            new LongOperation(NewActivity.this).execute("register", jo.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
    }

    public void onListItemClick(ListView list, View v, int position, long id) {
        cl = adapter.colors.get(position);
        Toast.makeText(NewActivity.this, adapter.colors.get(position).nume, Toast.LENGTH_LONG).show();
    }

    class LongOperation extends AsyncTask<String, Void, JSONObject> {
        public String myId;
        Context activity;

        public LongOperation(Context ctx) {
            activity = ctx;
        }

        @Override
        protected JSONObject doInBackground(String... params) {
            String action = params[0];
            try {
                JSONObject newJ = new JSONObject(params[1]);
            if (action.equals("register")) {
                String path = "http://ioana-mculic-jeopardy.iot.wyliodrin.com/register";
                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httpost = new HttpPost(path);
                StringEntity se = null;
                    se = new StringEntity(params[1]);
                    httpost.setEntity(se);
                    // httpost.setHeader("host", "http://ioana-mculic-jeopardy.iot.wyliodrin.com");
                    httpost.setHeader("Accept", "application/json");
                    httpost.setHeader("Content-type", "application/json");
                    ResponseHandler responseHandler = new BasicResponseHandler();
                    HttpResponse responsePost = httpclient.execute(httpost);
                    HttpEntity rasp_entity = responsePost.getEntity();
                    String resstr = EntityUtils.toString(rasp_entity);
                    System.out.println(resstr);
                    if (resstr != null) {
                        JSONObject myJson = new JSONObject(resstr);
                        if (myJson.getString("result").toString().equals("done"))
                            return newJ;
                        else
                            return null;
                    }
                }
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPostExecute(JSONObject result) {
            if (result == null) {

                Toast.makeText(NewActivity.this, "Datele nu au fost acceptate!", Toast.LENGTH_LONG).show();
            } else {
                Intent intent = new Intent(activity, Game.class);
                try {
                    intent.putExtra("name", result.getString("name"));
                    intent.putExtra("color", result.getString("color"));
                    startActivity(intent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }
    }
}